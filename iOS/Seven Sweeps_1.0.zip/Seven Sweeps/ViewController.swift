//
//  ViewController.swift
//  Seven Sweeps
//
//  Created by Mariano Hidalgo on 2/4/19.
//  Copyright © 2019 Txipirón Software. All rights reserved.
//

import UIKit
import WebKit



class ViewController: UIViewController, WKNavigationDelegate {

    let webView = WKWebView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        webView.frame = view.bounds
        webView.navigationDelegate = self
        
        let url = URL(string: "http://www.sevensweeps.com/es/home/")!
        let urlRequest = URLRequest(url: url)
        
        webView.load(urlRequest)
        webView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
        view.addSubview(webView)
    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == .linkActivated  {
            if let url = navigationAction.request.url,
                let host = url.host, !host.hasPrefix("http://www.sevensweeps.com/es/home/"),
                UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url)
                print(url)
                print("Redirigido al navegador. No es necesario abrirlo localmente.")
                decisionHandler(.cancel)
            } else {
                print("Abierto localmente")
                decisionHandler(.allow)
            }
        } else {
            print("No es un click de usuario")
            decisionHandler(.allow)
        }
    }

}

